package com.raktsanjivani.blood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class BloodApplication {

	public static void main(String[] args) {

		SpringApplication.run(BloodApplication.class, args);
	}

}
