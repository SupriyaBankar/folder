package com.raktsanjivani.blood.service;


import com.raktsanjivani.blood.entities.BloodStockEntity;
import com.raktsanjivani.blood.repositories.Bloodstockreposi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BloodstockService {
    @Autowired
    private Bloodstockreposi repository;

    // Get all blood inventories
    public List<BloodStockEntity> getAllInventories() {
        return repository.findAll();
    }

    // Get blood inventory by blood type
    public List<BloodStockEntity> getByBloodType(String bloodType) {
        return repository.findByBloodType(bloodType);
    }

    // Add new blood inventory
    public BloodStockEntity addInventory(BloodStockEntity inventory) {
        return repository.save(inventory);
    }

    // Update existing blood inventory
    public BloodStockEntity updateInventory(Long id, BloodStockEntity inventory) {
        BloodStockEntity existingInventory = repository.findById(id).orElseThrow();
        existingInventory.setBloodType(inventory.getBloodType());
        existingInventory.setComponent(inventory.getComponent());
        existingInventory.setUnitsAvailable(inventory.getUnitsAvailable());
        existingInventory.setLastChecked(inventory.getLastChecked());
        existingInventory.setRemarks(inventory.getRemarks());
        return repository.save(existingInventory);
    }

    // Delete blood inventory
    public void deleteInventory(Long id) {
        repository.deleteById(id);
    }
}
