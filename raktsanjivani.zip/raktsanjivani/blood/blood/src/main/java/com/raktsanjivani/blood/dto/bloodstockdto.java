package com.raktsanjivani.blood.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class bloodstockdto {
    private String blood_type;
    private String component;
    private int unit_availability;
    private String Remarks;
}
