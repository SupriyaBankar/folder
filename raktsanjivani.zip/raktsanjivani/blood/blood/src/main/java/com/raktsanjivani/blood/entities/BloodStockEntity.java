package com.raktsanjivani.blood.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Entity
@Table(name="bloodstock")
public class BloodStockEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String BloodType;

    @Column(nullable = false)
    private String Component;

    @Column(nullable = false)
    private int UnitsAvailable;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date LastChecked;

    @Column(length = 50)
    private String Remarks;

    public Object getBloodType() {
    }
}
