package com.raktsanjivani.blood.controllers;

import com.raktsanjivani.blood.dto.bloodstockdto;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Bloodstockontroller {
    private final BloodstockService bloodstockService;

    public Bloodstockontroller(BloodstockService bloodstockService) {
        this.bloodstockService = bloodstockService;
    }
    @GetMapping(path="/Bloodstock")
    public bloodstockdto getBloodstockbyId(@Pathvariable("Id") ,String){
        return BloodstockService.getBloodstockbyId();
    }
}
