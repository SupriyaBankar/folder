package com.raktsanjivani.blood.controllers;

public @interface Pathvariable {
}
