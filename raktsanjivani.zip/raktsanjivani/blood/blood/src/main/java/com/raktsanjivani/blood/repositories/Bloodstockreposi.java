package com.raktsanjivani.blood.repositories;

import com.raktsanjivani.blood.entities.BloodStockEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Bloodstockreposi extends JpaRepository<BloodStockEntity, Long> {
    List<Bloodstockreposi> findByBloodType(String bloodType);
}
